public class MaxNonAdjacent {
    public static int maxSum(int[] nums) {
        if (nums.length == 0) return 0;
        if (nums.length == 1) return nums[0];
    
        int prev2 = 0, prev1 = nums[0];
        for (int i = 1; i < nums.length; i++) {
            int take = nums[i] + prev2;
            int notTake = prev1;
            int current = Math.max(take, notTake);
            prev2 = prev1;
            prev1 = current;
        }
        return prev1;
    }
    public static void main(String[] args) {
        int[] arr = {2, 1, 4, 9};
        System.out.println("Max non-adjacent sum: " + maxSum(arr));
    }
}
