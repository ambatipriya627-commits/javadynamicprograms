public class FrogJump {
    public static int minJumps(int[] heights) {
        int jumps = 0;
        int i = 0;
        while (i < heights.length - 1) {
            int next = i;
            for (int j = i + 1; j < heights.length && j <= i + 2; j++) {
                if (j == heights.length - 1 || heights[j] < heights[next]) {
                    next = j;
                }
            }
            i = next;
            jumps++;
        }
        return jumps;
    } 
    public static void main(String[] args) {
        int[] heights = {10, 20, 30, 10, 10, 10};
        System.out.println("Minimum jumps: " + minJumps(heights));
    }
}
